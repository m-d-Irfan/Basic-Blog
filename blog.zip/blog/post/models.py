from django.db import models
from django.contrib.auth.models import User
from catagory.models import Catagory

class Post(models.Model):
    title     = models.CharField(max_length=100)
    content    = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    author  = models.ForeignKey(User,on_delete=models.SET_NULL,null=True)
    cata   = models.ForeignKey(Catagory,on_delete=models.SET_NULL,null=True,blank=True)

    def __str__(self):
        return self.title

